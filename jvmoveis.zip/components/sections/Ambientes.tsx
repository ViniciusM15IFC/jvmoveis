import {
  BedDouble,
  ChefHat,
  Sofa,
  Briefcase,
  Warehouse,
  Store,
  type LucideIcon,
} from "lucide-react";

const ambientes: { icon: LucideIcon; label: string }[] = [
  { icon: BedDouble, label: "Dormitórios" },
  { icon: ChefHat, label: "Cozinhas" },
  { icon: Sofa, label: "Salas" },
  { icon: Briefcase, label: "Escritórios" },
  { icon: Warehouse, label: "Áreas de Serviço" },
  { icon: Store, label: "Você escolhe!" },
];

export function Ambientes() {
  return (
    <section
      id="ambientes"
      className="md:flex items-start justify-start md:justify-center scroll-mt-24 px-8 md:px-16 py-16 bg-black border-t border-orange-500/30"
    >
      <div className="md:mr-16 mb-10 md:mb-0">
        <h2 className="font-display text-2xl md:text-3xl mb-2">MÓVEIS SOB MEDIDA PARA</h2>
        <h2 className="font-display text-2xl md:text-3xl text-orange-500 mb-10">TODOS OS AMBIENTES!</h2>
      </div>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-3xl">
        {ambientes.map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center gap-3 border-b border-neutral-800 pb-3">
            <Icon className="text-orange-500 shrink-0" size={26} strokeWidth={1.75} />
            <span className="font-display text-sm tracking-wide">{label}</span>
          </div>
        ))}
      </div>
    </section>
  )
}